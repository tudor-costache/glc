<?php
/**
 * Great Lake Cleaners — page-report-issue.php
 *
 * WordPress Template Name: Report an Issue
 *
 * Loaded automatically for the page with slug 'report-issue'.
 * Renders the [glc_report_form] shortcode inside a designed page shell.
 *
 * The page has two stages:
 *   1. Triage — routes city issues to Guelph's online tool, waterway issues to the form.
 *   2. Form  — collects waterway issue details, emailed to info@greatlakecleaners.ca.
 */

get_header();
?>

<div class="glc-fp-wrapper">
<div class="glc-submit-page-wrap glc-report-page-wrap">

    <!-- Page header -->
    <header class="glc-submit-page-header">
        <span class="glc-fp-label"><?php esc_html_e( 'Waterways', 'great-lake-cleaners' ); ?></span>
        <h1 class="glc-submit-page-h1"><?php esc_html_e( 'Report an Issue', 'great-lake-cleaners' ); ?></h1>
        <p class="glc-submit-page-intro">
            <?php esc_html_e( 'We\'re all doing our part to keep our waterways clean. If you see something that shouldn\'t be there, getting it documented is the first step to getting it out. The City of Guelph has extensive resources to clean up city parks and property. Where needed we can paddle to more remote locations for smaller items polluting our rivers.', 'great-lake-cleaners' ); ?>
        </p>
    </header>

    <!-- Two-column layout: form left, sidebar right -->
    <div class="glc-submit-layout">

        <!-- Form / triage column -->
        <div class="glc-submit-form-col">
            <?php echo do_shortcode( '[glc_report_form]' ); ?>
        </div>

        <!-- Sidebar column -->
        <aside class="glc-submit-sidebar" aria-label="<?php esc_attr_e( 'Reporting guidance', 'great-lake-cleaners' ); ?>">

            <div class="glc-sidebar-card">
                <h2 class="glc-sidebar-heading"><?php esc_html_e( 'What happens next?', 'great-lake-cleaners' ); ?></h2>
                <ol class="glc-sidebar-steps">
                    <li>
                        <strong><?php esc_html_e( 'We log it', 'great-lake-cleaners' ); ?></strong>
                        <span><?php esc_html_e( 'Every waterway report goes into our notes.', 'great-lake-cleaners' ); ?></span>
                    </li>
                    <li>
                        <strong><?php esc_html_e( 'We visit', 'great-lake-cleaners' ); ?></strong>
                        <span><?php esc_html_e( 'We prioritize reported issues on our next outing to that corridor and assess what\'s needed.', 'great-lake-cleaners' ); ?></span>
                    </li>
                    <li>
                        <strong><?php esc_html_e( 'We escalate when needed', 'great-lake-cleaners' ); ?></strong>
                        <span><?php esc_html_e( 'Hazardous material or large-scale dumping gets flagged to the GRCA or City.', 'great-lake-cleaners' ); ?></span>
                    </li>
                </ol>
            </div>

            <div class="glc-sidebar-card glc-sidebar-card--tips">
                <h2 class="glc-sidebar-heading"><?php esc_html_e( 'Tips for a good report', 'great-lake-cleaners' ); ?></h2>
                <ul class="glc-sidebar-tips">
                    <li>
                        <span class="glc-tip-icon">📍</span>
                        <span><?php esc_html_e( 'Location is the most important detail — a bridge name, park, or street intersection narrows it down fast.', 'great-lake-cleaners' ); ?></span>
                    </li>
                    <li>
                        <span class="glc-tip-icon">📸</span>
                        <span><?php esc_html_e( 'A photo of the issue and one of the surroundings is worth a thousand words. Shoot before you leave the spot.', 'great-lake-cleaners' ); ?></span>
                    </li>
                    <li>
                        <span class="glc-tip-icon">⚠️</span>
                        <span>
                            <?php esc_html_e( 'If the issue looks like an active spill or chemical hazard, call the', 'great-lake-cleaners' ); ?>
                            <strong><?php esc_html_e( 'GRCA Spills Line', 'great-lake-cleaners' ); ?></strong>
                            <?php esc_html_e( 'at', 'great-lake-cleaners' ); ?>
                            <a href="tel:1-800-265-6613">1-800-265-6613</a>
                            <?php esc_html_e( '(24 hr).', 'great-lake-cleaners' ); ?>
                        </span>
                    </li>
                    <li>
                        <span class="glc-tip-icon">🐾</span>
                        <span><?php esc_html_e( 'Don\'t put yourself at risk — report from a safe distance. Notes on what you couldn\'t see up close are still useful.', 'great-lake-cleaners' ); ?></span>
                    </li>
                </ul>
            </div>

            <div class="glc-sidebar-card glc-sidebar-card--corridors">
                <h2 class="glc-sidebar-heading"><?php esc_html_e( 'Places we visit', 'great-lake-cleaners' ); ?></h2>
                <div class="glc-sidebar-corridors">
                    <div class="glc-sidebar-corridor">
                        <span><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/icon-wave.svg" alt="" width="20" height="20" style="vertical-align:-0.2em;flex-shrink:0;width:1.3em;height:1.3em" aria-hidden="true"></span>
                        <div>
                            <strong><?php esc_html_e( 'Speed River', 'great-lake-cleaners' ); ?></strong>
                            <span><?php esc_html_e( 'Shore & paddle', 'great-lake-cleaners' ); ?></span>
                        </div>
                    </div>
                    <div class="glc-sidebar-corridor">
                        <span>🌿</span>
                        <div>
                            <strong><?php esc_html_e( 'Eramosa River', 'great-lake-cleaners' ); ?></strong>
                            <span><?php esc_html_e( 'Shore access', 'great-lake-cleaners' ); ?></span>
                        </div>
                    </div>
                    <div class="glc-sidebar-corridor">
                        <span>🦆</span>
                        <div>
                            <strong><?php esc_html_e( 'Hanlon Creek', 'great-lake-cleaners' ); ?></strong>
                            <span><?php esc_html_e( 'Trail corridor', 'great-lake-cleaners' ); ?></span>
                        </div>
                    </div>
                </div>
                <p class="glc-sidebar-note">
                    <?php esc_html_e( "Not sure which waterway? Select 'Not sure' — the location description is what matters most.", 'great-lake-cleaners' ); ?>
                </p>
            </div>

        </aside><!-- .glc-submit-sidebar -->
    </div><!-- .glc-submit-layout -->

</div><!-- .glc-report-page-wrap -->
</div><!-- .glc-fp-wrapper -->

<?php get_footer(); ?>
