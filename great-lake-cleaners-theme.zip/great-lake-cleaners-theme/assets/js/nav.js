( function() {
    var toggle = document.querySelector( '.glc-menu-toggle' );
    var menu   = document.querySelector( '.glc-nav-menu' );

    if ( ! toggle || ! menu ) return;

    toggle.addEventListener( 'click', function() {
        var expanded = toggle.getAttribute( 'aria-expanded' ) === 'true';
        toggle.setAttribute( 'aria-expanded', String( ! expanded ) );
        menu.classList.toggle( 'is-open', ! expanded );
    } );

    // Close on outside click
    document.addEventListener( 'click', function( e ) {
        if ( ! e.target.closest( '#glc-site-header' ) ) {
            toggle.setAttribute( 'aria-expanded', 'false' );
            menu.classList.remove( 'is-open' );
        }
    } );
} )();
