<?php
/**
 * Great Lake Cleaners — functions.php
 * Theme setup: nav menus, featured images, font enqueue, body class helpers.
 */

defined( 'ABSPATH' ) || exit;

define( 'GLC_THEME_VERSION', '1.0.0' );

// ── Theme setup ───────────────────────────────────────────────────────────────
add_action( 'after_setup_theme', function() {

    load_theme_textdomain( 'great-lake-cleaners', get_stylesheet_directory() . '/languages' );

    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', [ 'search-form', 'comment-form', 'gallery', 'caption', 'navigation-widgets' ] );
    add_theme_support( 'custom-logo', [
        'height'      => 200,
        'width'       => 200,
        'flex-height' => true,
        'flex-width'  => true,
    ] );

    register_nav_menus( [
        'primary' => __( 'Primary Navigation', 'great-lake-cleaners' ),
        'footer'  => __( 'Footer Navigation',  'great-lake-cleaners' ),
    ] );
} );

// ── Enqueue styles and fonts ──────────────────────────────────────────────────
add_action( 'wp_enqueue_scripts', function() {

    // Google Fonts — Nunito (display) + Lato (body)
    wp_enqueue_style(
        'glc-fonts',
        'https://fonts.googleapis.com/css2?family=Nunito:wght@700;800;900&family=Lato:wght@400;700&display=swap',
        [],
        null
    );

    // Main stylesheet
    wp_enqueue_style(
        'glc-style',
        get_stylesheet_uri(),
        [ 'glc-fonts' ],
        GLC_THEME_VERSION
    );

    // Mobile nav toggle script
    wp_enqueue_script(
        'glc-nav',
        get_stylesheet_directory_uri() . '/assets/js/nav.js',
        [],
        GLC_THEME_VERSION,
        true
    );
} );

// ── Nav fallback — renders basic links if no menu is assigned ─────────────────
function glc_nav_fallback() {
    echo '<ul class="glc-nav-menu glc-nav-fallback">';
    echo '<li><a href="' . esc_url( home_url( '/' ) ) . '">'
        . esc_html__( 'Home', 'great-lake-cleaners' ) . '</a></li>';

    $archive = get_post_type_archive_link( 'cleanup_event' );
    if ( $archive ) {
        echo '<li><a href="' . esc_url( $archive ) . '">'
            . esc_html__( 'Cleanups', 'great-lake-cleaners' ) . '</a></li>';
    }

    $about = get_page_by_path( 'about' );
    if ( $about ) {
        echo '<li><a href="' . esc_url( get_permalink( $about ) ) . '">'
            . esc_html__( 'About', 'great-lake-cleaners' ) . '</a></li>';
    }
    echo '</ul>';
}

// ── Body classes ──────────────────────────────────────────────────────────────
add_filter( 'body_class', function( $classes ) {
    if ( is_singular( 'cleanup_event' ) ) {
        $classes[] = 'glc-single-cleanup';
    }
    if ( is_post_type_archive( 'cleanup_event' ) ) {
        $classes[] = 'glc-archive-cleanup';
    }
    return $classes;
} );
