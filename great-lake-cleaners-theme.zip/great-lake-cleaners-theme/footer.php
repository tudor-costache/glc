<?php
/**
 * Great Lake Cleaners — footer.php
 * Closes <main> opened in header.php, outputs site footer.
 */
?>

</main><!-- #main-content -->

<footer id="glc-site-footer" class="glc-site-footer" role="contentinfo">
    <div class="glc-footer-inner">

        <div class="glc-footer-brand">
            <p class="glc-footer-name">Great Lake Cleaners</p>
            <p class="glc-footer-tagline">The lake starts here.</p>
            <p class="glc-footer-location">Guelph, Ontario &nbsp;·&nbsp; greatlakecleaners.ca</p>
        </div>

        <nav class="glc-footer-nav" aria-label="<?php esc_attr_e( 'Footer navigation', 'great-lake-cleaners' ); ?>">
            <?php
            wp_nav_menu( [
                'theme_location' => 'footer',
                'menu_class'     => 'glc-footer-menu',
                'container'      => false,
                'depth'          => 1,
                'fallback_cb'    => false,
            ] );
            ?>
        </nav>

        <div class="glc-footer-social">
            <a href="https://instagram.com/greatlakecleaners"
               target="_blank" rel="noopener noreferrer"
               aria-label="<?php esc_attr_e( 'Instagram', 'great-lake-cleaners' ); ?>">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
                     stroke="currentColor" stroke-width="1.8" stroke-linecap="round">
                    <rect x="2" y="2" width="20" height="20" rx="5"/>
                    <circle cx="12" cy="12" r="5"/>
                    <circle cx="17.5" cy="6.5" r="1.5" fill="currentColor" stroke="none"/>
                </svg>
            </a>
        </div>

    </div>
    <div class="glc-footer-base">
        <p>&copy; <?php echo esc_html( date( 'Y' ) ); ?>
            <?php bloginfo( 'name' ); ?> &nbsp;·&nbsp;
            <?php esc_html_e( 'Cleaning Guelph\'s waterways, one stretch at a time.', 'great-lake-cleaners' ); ?>
        </p>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
