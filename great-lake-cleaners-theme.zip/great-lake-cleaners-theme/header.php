<?php
/**
 * Great Lake Cleaners — header.php
 *
 * Used by: all page templates (index, archive, single, page, front-page)
 * Outputs: <head>, site header, nav bar, and opening <main> tag.
 * Close with footer.php which outputs </main> and </body></html>.
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="glc-skip-link screen-reader-text" href="#main-content">
    <?php esc_html_e( 'Skip to content', 'great-lake-cleaners' ); ?>
</a>

<!-- ═══════════════════════════════════════════════════════
     SITE HEADER
════════════════════════════════════════════════════════ -->
<header id="glc-site-header" class="glc-site-header" role="banner">

    <div class="glc-header-top">
        <div class="glc-header-inner">

            <!-- Badge / Logo -->
            <div class="glc-logo-wrap">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" aria-label="<?php bloginfo( 'name' ); ?> — Home">
                    <?php
                    $logo_id = get_theme_mod( 'custom_logo' );
                    if ( $logo_id ) :
                        $logo_url = wp_get_attachment_image_url( $logo_id, 'full' );
                        ?>
                        <img src="<?php echo esc_url( $logo_url ); ?>"
                             alt="<?php bloginfo( 'name' ); ?> badge"
                             class="glc-badge-img"
                             width="100" height="100">
                    <?php else : ?>
                        <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/images/glc-badge.png' ); ?>"
                             alt="<?php bloginfo( 'name' ); ?> badge"
                             class="glc-badge-img"
                             width="100" height="100">
                    <?php endif; ?>
                </a>
            </div>

            <!-- Brand text -->
            <div class="glc-brand-text">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="glc-brand-name" rel="home">
                    <?php esc_html_e( 'Great Lake ', 'great-lake-cleaners' ); ?>
                    <span><?php esc_html_e( 'Cleaners', 'great-lake-cleaners' ); ?></span>
                </a>
                <p class="glc-brand-tag">
                    <?php esc_html_e( 'The lake starts here', 'great-lake-cleaners' ); ?>
                    <span class="glc-brand-sep" aria-hidden="true">&nbsp;·&nbsp;</span>
                    <?php esc_html_e( 'Guelph, Ontario', 'great-lake-cleaners' ); ?>
                </p>
            </div>

            <!-- Header actions -->
            <div class="glc-header-actions">
                <a href="https://instagram.com/greatlakecleaners"
                   class="glc-insta-link"
                   target="_blank"
                   rel="noopener noreferrer"
                   aria-label="<?php esc_attr_e( 'Follow us on Instagram', 'great-lake-cleaners' ); ?>">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                         stroke="currentColor" stroke-width="2" stroke-linecap="round"
                         aria-hidden="true" focusable="false">
                        <rect x="2" y="2" width="20" height="20" rx="5"/>
                        <circle cx="12" cy="12" r="5"/>
                        <circle cx="17.5" cy="6.5" r="1.5" fill="currentColor" stroke="none"/>
                    </svg>
                    @greatlakecleaners
                </a>

                <?php
                // "Support a Cleanup" — links to a page with slug 'support' if it exists,
                // otherwise falls back to the donations/contact page or '#'.
                $support_page = get_page_by_path( 'support' );
                $support_url  = $support_page ? get_permalink( $support_page ) : '#';
                ?>
                <a href="<?php echo esc_url( $support_url ); ?>" class="glc-support-btn">
                    <?php esc_html_e( 'Support a Cleanup', 'great-lake-cleaners' ); ?>
                </a>
            </div>

            <!-- Mobile menu toggle -->
            <button class="glc-menu-toggle"
                    aria-controls="glc-primary-nav"
                    aria-expanded="false"
                    aria-label="<?php esc_attr_e( 'Toggle navigation menu', 'great-lake-cleaners' ); ?>">
                <span class="glc-hamburger" aria-hidden="true">
                    <span></span><span></span><span></span>
                </span>
            </button>

        </div><!-- .glc-header-inner -->
    </div><!-- .glc-header-top -->

    <!-- Navigation bar -->
    <nav id="glc-primary-nav" class="glc-nav-bar" role="navigation"
         aria-label="<?php esc_attr_e( 'Primary navigation', 'great-lake-cleaners' ); ?>">
        <div class="glc-nav-inner">
            <?php
            wp_nav_menu( [
                'theme_location' => 'primary',
                'menu_id'        => 'glc-primary-menu',
                'menu_class'     => 'glc-nav-menu',
                'container'      => false,
                'fallback_cb'    => 'glc_nav_fallback',
            ] );
            ?>
        </div>
    </nav>

</header><!-- #glc-site-header -->


<!-- ═══════════════════════════════════════════════════════
     HERO (front page only)
     On the front page template, this outputs the hero section
     and stats strip. On interior pages, the template handles
     its own page title / breadcrumb area instead.
════════════════════════════════════════════════════════ -->
<?php if ( is_front_page() ) : ?>

<section class="glc-hero" aria-label="<?php esc_attr_e( 'Introduction', 'great-lake-cleaners' ); ?>">
    <div class="glc-hero-inner">

        <p class="glc-hero-location">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none"
                 stroke="currentColor" stroke-width="2.5" stroke-linecap="round"
                 aria-hidden="true" focusable="false">
                <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z"/>
                <circle cx="12" cy="9" r="2.5"/>
            </svg>
            <?php esc_html_e( 'Speed River · Eramosa · Hanlon Creek', 'great-lake-cleaners' ); ?>
        </p>

        <h1 class="glc-hero-h1">
            <?php esc_html_e( 'Cleaning up what flows to ', 'great-lake-cleaners' ); ?>
            <em><?php esc_html_e( 'the Great Lakes', 'great-lake-cleaners' ); ?></em>
        </h1>

        <p class="glc-hero-body">
            <?php esc_html_e(
                'Shore and paddle cleanups along Guelph\'s river corridors — because what enters our waterways reaches Lake Erie.',
                'great-lake-cleaners'
            ); ?>
        </p>

        <div class="glc-cta-row">
            <?php
            $cleanups_page = get_page_by_path( 'cleanups' );
            $cleanups_url  = $cleanups_page
                ? get_permalink( $cleanups_page )
                : get_post_type_archive_link( 'cleanup_event' );
            ?>
            <a href="<?php echo esc_url( $cleanups_url ?: '#' ); ?>" class="glc-btn-primary">
                <?php esc_html_e( 'See Our Cleanups', 'great-lake-cleaners' ); ?>
            </a>
            <a href="https://instagram.com/greatlakecleaners"
               class="glc-btn-outline"
               target="_blank" rel="noopener noreferrer">
                <?php esc_html_e( 'Follow Along', 'great-lake-cleaners' ); ?>
            </a>
        </div>

    </div>
</section>

<!-- Wave divider -->
<div class="glc-wave-divider" aria-hidden="true">
    <svg viewBox="0 0 1200 36" xmlns="http://www.w3.org/2000/svg"
         preserveAspectRatio="none" width="100%" height="36">
        <path d="M0,18 C150,36 350,0 600,18 C850,36 1050,0 1200,18 L1200,36 L0,36 Z"
              fill="#1a4a6b"/>
    </svg>
</div>

<!-- Stats strip — powered by [glc_stats] shortcode data -->
<div class="glc-stats-strip" aria-label="<?php esc_attr_e( 'Cumulative impact', 'great-lake-cleaners' ); ?>">
    <?php
    // Pull stats directly from cleanup_event post meta for live data
    $events = get_posts( [
        'post_type'      => 'cleanup_event',
        'post_status'    => 'publish',
        'posts_per_page' => -1,
        'fields'         => 'ids',
    ] );

    $total_cleanups   = count( $events );
    $total_weight     = 0;
    $total_hours      = 0;

    foreach ( $events as $id ) {
        $total_weight += (float) get_post_meta( $id, 'weight_kg',  true );
        $total_hours  += (float) get_post_meta( $id, 'hours',      true );
    }
    ?>
    <div class="glc-stat">
        <span class="glc-stat-val">
            <?php echo esc_html( $total_cleanups ); ?><sup>+</sup>
        </span>
        <span class="glc-stat-lbl"><?php esc_html_e( 'Cleanups', 'great-lake-cleaners' ); ?></span>
    </div>
    <div class="glc-stat">
        <span class="glc-stat-val">
            <?php echo esc_html( number_format( $total_weight, 0 ) ); ?><sup> kg</sup>
        </span>
        <span class="glc-stat-lbl"><?php esc_html_e( 'Debris Removed', 'great-lake-cleaners' ); ?></span>
    </div>
    <div class="glc-stat">
        <span class="glc-stat-val">
            <?php echo esc_html( number_format( $total_hours, 0 ) ); ?><sup>+</sup>
        </span>
        <span class="glc-stat-lbl"><?php esc_html_e( 'Volunteer Hours', 'great-lake-cleaners' ); ?></span>
    </div>
    <div class="glc-stat">
        <span class="glc-stat-val">3</span>
        <span class="glc-stat-lbl"><?php esc_html_e( 'River Corridors', 'great-lake-cleaners' ); ?></span>
    </div>
</div>

<?php endif; // is_front_page() ?>

<!-- ═══════════════════════════════════════════════════════
     MAIN CONTENT AREA OPENS HERE
     Closed in footer.php with </main>
════════════════════════════════════════════════════════ -->
<main id="main-content" class="glc-main">
