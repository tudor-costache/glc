<?php
/**
 * Shortcodes
 *
 * [glc_stats]   — cumulative totals banner
 * [glc_map]     — Leaflet map of all cleanup sites
 * [glc_archive] — recent cleanups list (fallback if theme doesn't handle CPT archive)
 */
defined( 'ABSPATH' ) || exit;

// ── Helpers ──────────────────────────────────────────────────────────────────

function glc_get_all_events() {
    return get_posts( [
        'post_type'      => 'cleanup_event',
        'post_status'    => 'publish',
        'posts_per_page' => -1,
        'orderby'        => 'meta_value',
        'meta_key'       => 'cleanup_date',
        'order'          => 'DESC',
    ] );
}

function glc_meta( $post_id, $key, $default = 0 ) {
    $val = get_post_meta( $post_id, $key, true );
    return ( $val !== '' && $val !== false ) ? $val : $default;
}

// ── [glc_stats] ──────────────────────────────────────────────────────────────

add_shortcode( 'glc_stats', 'glc_shortcode_stats' );
function glc_shortcode_stats( $atts ) {
    $events = glc_get_all_events();
    if ( empty( $events ) ) return '';

    $totals = [
        'events'     => count( $events ),
        'volunteers' => 0,
        'hours'      => 0.0,
        'bags'       => 0,
        'weight_kg'  => 0.0,
        'planted'    => 0,
    ];

    foreach ( $events as $e ) {
        $id = $e->ID;
        $totals['volunteers'] += (int)   glc_meta( $id, 'volunteers' );
        $totals['hours']      += (float) glc_meta( $id, 'hours' );
        $totals['bags']       += (int)   glc_meta( $id, 'bags' );
        $totals['weight_kg']  += (float) glc_meta( $id, 'weight_kg' );
        $totals['planted']    += (int)   glc_meta( $id, 'species_planted' );
    }

    $stats = [
        [ 'value' => $totals['events'],                   'label' => 'Cleanups' ],
        [ 'value' => $totals['volunteers'],               'label' => 'Volunteers' ],
        [ 'value' => number_format( $totals['hours'], 1 ),'label' => 'Hours' ],
        [ 'value' => $totals['bags'],                     'label' => 'Bags Out' ],
        [ 'value' => number_format( $totals['weight_kg'], 0 ) . ' kg', 'label' => 'Debris Removed' ],
    ];
    if ( $totals['planted'] > 0 ) {
        $stats[] = [ 'value' => $totals['planted'], 'label' => 'Plants In' ];
    }

    ob_start(); ?>
    <div class="glc-stats-banner">
        <?php foreach ( $stats as $s ) : ?>
        <div class="glc-stat">
            <span class="glc-stat-value"><?php echo esc_html( $s['value'] ); ?></span>
            <span class="glc-stat-label"><?php echo esc_html( $s['label'] ); ?></span>
        </div>
        <?php endforeach; ?>
    </div>
    <?php
    return ob_get_clean();
}

// ── [glc_map] ────────────────────────────────────────────────────────────────

add_shortcode( 'glc_map', 'glc_shortcode_map' );
function glc_shortcode_map( $atts ) {
    $atts = shortcode_atts( [
        'height'  => '480px',
        'post_id' => 0,          // if set, render a single-event map
    ], $atts );

    // Single-event mode (used on single-cleanup_event.php and single-glc_submission.php)
    if ( (int) $atts['post_id'] > 0 ) {
        $pid = (int) $atts['post_id'];
        // Try tracker meta keys first, then glc_ prefixed keys (community submissions)
        $lat = (float) glc_meta( $pid, 'gps_lat', 0 );
        $lon = (float) glc_meta( $pid, 'gps_lon', 0 );
        if ( ! $lat || ! $lon ) {
            $lat = (float) glc_meta( $pid, 'glc_gps_lat', 0 );
            $lon = (float) glc_meta( $pid, 'glc_gps_lon', 0 );
        }
        if ( ! $lat || ! $lon ) return ''; // no coords — skip map
        $markers = [ [
            'lat'   => $lat,
            'lon'   => $lon,
            'title' => get_the_title( $pid ),
            'date'  => glc_meta( $pid, 'cleanup_date', '' ),
            'bags'  => (int) glc_meta( $pid, 'bags' ),
            'url'   => get_permalink( $pid ),
        ] ];
    } else {
        // All-events mode — deduplicate by location, keep highest-stats event per pin
        $events = glc_get_all_events();
        $by_location = [];
        foreach ( $events as $e ) {
            $lat = (float) glc_meta( $e->ID, 'gps_lat', 0 );
            $lon = (float) glc_meta( $e->ID, 'gps_lon', 0 );
            if ( ! $lat || ! $lon ) continue;

            // Round to 5 decimal places for key (~1 m precision)
            $key = round( $lat, 5 ) . ',' . round( $lon, 5 );

            $score = (float) glc_meta( $e->ID, 'weight_kg' )
                   + (int)   glc_meta( $e->ID, 'bags' ) * 2; // weight is primary; bags as tiebreak

            if ( ! isset( $by_location[ $key ] ) || $score > $by_location[ $key ]['score'] ) {
                $by_location[ $key ] = [
                    'score' => $score,
                    'lat'   => $lat,
                    'lon'   => $lon,
                    'title' => get_the_title( $e->ID ),
                    'date'  => glc_meta( $e->ID, 'cleanup_date', '' ),
                    'bags'  => (int) glc_meta( $e->ID, 'bags' ),
                    'url'   => get_permalink( $e->ID ),
                ];
            }
        }
        $markers = array_values( $by_location );
    }

    // Enqueue Leaflet
    wp_enqueue_style(
        'leaflet',
        'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css',
        [], '1.9.4'
    );
    wp_enqueue_script(
        'leaflet',
        'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js',
        [], '1.9.4', true
    );

    $map_id = 'glc-map-' . wp_rand( 1000, 9999 );
    ob_start(); ?>
    <div id="<?php echo esc_attr( $map_id ); ?>"
         class="glc-map"
         style="height:<?php echo esc_attr( $atts['height'] ); ?>; width:100%; border-radius:8px;">
    </div>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        var markers = <?php echo wp_json_encode( $markers ); ?>;
        var map = L.map(<?php echo wp_json_encode( $map_id ); ?>, { zoomControl: false }).setView([43.545, -80.248], 12);
        L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
            attribution: '© <a href="https://openstreetmap.org/copyright">OpenStreetMap</a> contributors © <a href="https://carto.com/attributions">CARTO</a>',
            subdomains: 'abcd',
            maxZoom: 19
        }).addTo(map);

        var icon = L.divIcon({
            className: 'glc-marker',
            html: '<svg width="20" height="26" viewBox="0 0 20 26" xmlns="http://www.w3.org/2000/svg"><path d="M10 0C4.48 0 0 4.48 0 10c0 7.5 10 16 10 16s10-8.5 10-16C20 4.48 15.52 0 10 0z" fill="#1a4a6b"/><circle cx="10" cy="10" r="4" fill="#ffffff"/></svg>',
            iconSize: [20, 26],
            iconAnchor: [10, 26],
            popupAnchor: [0, -28],
        });

        markers.forEach(function(m) {
            var popup = '<strong>' + m.title + '</strong><br>'
                      + m.date + '<br>'
                      + m.bags + ' bags collected<br>'
                      + '<a href="' + m.url + '">View details →</a>';
            L.marker([m.lat, m.lon], {icon: icon})
             .addTo(map)
             .bindPopup(popup);
        });

        // Fit bounds or zoom to single pin
        if (markers.length === 1) {
            map.setView([markers[0].lat, markers[0].lon], 15);
        } else if (markers.length > 1) {
            var latlngs = markers.map(function(m){ return [m.lat, m.lon]; });
            map.fitBounds(latlngs, {padding: [40, 40]});
        }
    });
    </script>
    <?php
    return ob_get_clean();
}

// ── [glc_archive] ────────────────────────────────────────────────────────────

add_shortcode( 'glc_archive', 'glc_shortcode_archive' );
function glc_shortcode_archive( $atts ) {
    $atts   = shortcode_atts( [ 'limit' => 20 ], $atts );
    $events = get_posts( [
        'post_type'      => 'cleanup_event',
        'post_status'    => 'publish',
        'posts_per_page' => (int) $atts['limit'],
        'orderby'        => 'meta_value',
        'meta_key'       => 'cleanup_date',
        'order'          => 'DESC',
    ] );

    if ( empty( $events ) ) {
        return '<p>No cleanups logged yet. Check back soon!</p>';
    }

    ob_start(); ?>
    <div class="glc-archive">
        <?php foreach ( $events as $e ) :
            $id       = $e->ID;
            $date     = glc_meta( $id, 'cleanup_date', '' );
            $site     = glc_meta( $id, 'site_name', get_the_title( $id ) );
            $vols     = (int)   glc_meta( $id, 'volunteers' );
            $bags     = (int)   glc_meta( $id, 'bags' );
            $weight   = (float) glc_meta( $id, 'weight_kg' );
            $planted  = (int)   glc_meta( $id, 'species_planted' );
            $wildlife = glc_meta( $id, 'wildlife_obs', '' );
            $date_fmt = $date ? date( 'F j, Y', strtotime( $date ) ) : '';
        ?>
        <article class="glc-event-card">
            <div class="glc-event-meta">
                <time class="glc-event-date"><?php echo esc_html( $date_fmt ); ?></time>
            </div>
            <h3 class="glc-event-title">
                <a href="<?php echo esc_url( get_permalink( $id ) ); ?>">
                    <?php echo esc_html( $site ); ?>
                </a>
            </h3>
            <div class="glc-event-stats">
                <span>👥 <?php echo $vols; ?> volunteers</span>
                <span>🛍 <?php echo $bags; ?> bags</span>
                <span>⚖ <?php echo number_format( $weight, 0 ); ?> kg</span>
                <?php if ( $planted ) : ?>
                <span>🌿 <?php echo $planted; ?> plants</span>
                <?php endif; ?>
            </div>
            <?php if ( $wildlife ) : ?>
            <p class="glc-event-wildlife">👀 <?php echo esc_html( $wildlife ); ?></p>
            <?php endif; ?>
        </article>
        <?php endforeach; ?>
    </div>
    <?php
    return ob_get_clean();
}

// ── [glc_gallery] ────────────────────────────────────────────────────────────
// Renders a year-tabbed photo grid with a vanilla JS lightbox.
// Sources:
//   - Images attached to cleanup_event posts (uploaded while editing)
//   - Images attached to published glc_submission posts where repost consent = '1'
// Year is derived from the cleanup_date meta (events) or glc_cleanup_date meta (submissions).

add_shortcode( 'glc_gallery', 'glc_shortcode_gallery' );
function glc_shortcode_gallery( $atts ) {

    // ── 1. Collect all source posts ──────────────────────────────────────────

    $event_posts = get_posts( [
        'post_type'      => 'cleanup_event',
        'post_status'    => 'publish',
        'posts_per_page' => -1,
    ] );

    $sub_posts = get_posts( [
        'post_type'      => 'glc_submission',
        'post_status'    => 'publish',
        'posts_per_page' => -1,
        'meta_query'     => [ [
            'key'   => 'glc_photo_repost_ok',
            'value' => '1',
        ] ],
    ] );

    // ── 2. Build photo list grouped by year ──────────────────────────────────

    $by_year = [];  // [ year => [ [ src, thumb, title, date, url, alt ] ] ]

    // Helper: add attachments for a post
    $add_attachments = function( $post_id, $date_str, $label, $post_url ) use ( &$by_year ) {
        $year = $date_str ? intval( substr( $date_str, 0, 4 ) ) : intval( date( 'Y' ) );
        if ( $year < 2000 || $year > 2100 ) $year = intval( date( 'Y' ) );

        $attachments = get_posts( [
            'post_type'      => 'attachment',
            'post_status'    => 'inherit',
            'post_parent'    => $post_id,
            'post_mime_type' => 'image',
            'posts_per_page' => -1,
            'orderby'        => 'menu_order',
            'order'          => 'ASC',
        ] );

        foreach ( $attachments as $att ) {
            $src   = wp_get_attachment_image_url( $att->ID, 'large' );
            $thumb = wp_get_attachment_image_url( $att->ID, 'medium' );
            if ( ! $src || ! $thumb ) continue;

            $alt = get_post_meta( $att->ID, '_wp_attachment_image_alt', true );
            if ( ! $alt ) $alt = $label;

            $by_year[ $year ][] = [
                'src'   => $src,
                'thumb' => $thumb,
                'alt'   => $alt,
                'label' => $label,
                'date'  => $date_str,
                'url'   => $post_url,
            ];
        }
    };

    foreach ( $event_posts as $e ) {
        $date  = glc_meta( $e->ID, 'cleanup_date', '' );
        $label = glc_meta( $e->ID, 'site_name', get_the_title( $e->ID ) );
        $add_attachments( $e->ID, $date, $label, get_permalink( $e->ID ) );
    }

    foreach ( $sub_posts as $s ) {
        $date  = get_post_meta( $s->ID, 'glc_cleanup_date', true );
        $label = get_post_meta( $s->ID, 'glc_site_name', true ) ?: get_the_title( $s->ID );
        // Community submissions: pull from glc_photo_ids meta (may differ from post_parent)
        $photo_ids = get_post_meta( $s->ID, 'glc_photo_ids', true );
        if ( ! empty( $photo_ids ) ) {
            $year = $date ? intval( substr( $date, 0, 4 ) ) : intval( date( 'Y' ) );
            if ( $year < 2000 || $year > 2100 ) $year = intval( date( 'Y' ) );
            foreach ( (array) $photo_ids as $att_id ) {
                $src   = wp_get_attachment_image_url( $att_id, 'large' );
                $thumb = wp_get_attachment_image_url( $att_id, 'medium' );
                if ( ! $src || ! $thumb ) continue;
                $alt = get_post_meta( $att_id, '_wp_attachment_image_alt', true ) ?: $label;
                $by_year[ $year ][] = [
                    'src'   => $src,
                    'thumb' => $thumb,
                    'alt'   => $alt,
                    'label' => $label,
                    'date'  => $date,
                    'url'   => get_permalink( $s->ID ),
                ];
            }
        } else {
            // Fallback: also try post_parent attachments for submissions
            $add_attachments( $s->ID, $date, $label, get_permalink( $s->ID ) );
        }
    }

    if ( empty( $by_year ) ) {
        return '<p class="glc-gallery-empty">No photos yet — check back after our next outing!</p>';
    }

    // Sort years descending
    krsort( $by_year );
    $years = array_keys( $by_year );
    $first = $years[0];

    // Flatten all photos into a single indexed array for lightbox navigation
    $all_photos = [];
    foreach ( $by_year as $yr => $photos ) {
        foreach ( $photos as $p ) {
            $p['year'] = $yr;
            $all_photos[] = $p;
        }
    }

    // Build per-year offset map so lightbox can navigate within year or globally
    $year_offsets = [];
    $offset = 0;
    foreach ( $by_year as $yr => $photos ) {
        $year_offsets[ $yr ] = $offset;
        $offset += count( $photos );
    }

    $gallery_id = 'glc-gallery-' . wp_rand( 1000, 9999 );

    ob_start(); ?>
    <div class="glc-gallery-wrap" id="<?php echo esc_attr( $gallery_id ); ?>">

        <?php if ( count( $years ) > 1 ) : ?>
        <!-- Year tabs -->
        <div class="glc-gallery-tabs" role="tablist" aria-label="Filter photos by year">
            <?php foreach ( $years as $yr ) : ?>
            <button
                class="glc-gallery-tab<?php echo $yr === $first ? ' glc-tab-active' : ''; ?>"
                role="tab"
                aria-selected="<?php echo $yr === $first ? 'true' : 'false'; ?>"
                data-year="<?php echo esc_attr( $yr ); ?>">
                <?php echo esc_html( $yr ); ?>
                <span class="glc-tab-count"><?php echo count( $by_year[ $yr ] ); ?></span>
            </button>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <!-- Photo grids — one per year, only active one visible -->
        <?php foreach ( $by_year as $yr => $photos ) :
            $global_start = $year_offsets[ $yr ];
        ?>
        <div class="glc-gallery-grid<?php echo $yr === $first ? ' glc-grid-active' : ''; ?>"
             data-year="<?php echo esc_attr( $yr ); ?>"
             role="tabpanel">
            <?php foreach ( $photos as $i => $photo ) :
                $global_idx = $global_start + $i;
            ?>
            <button
                class="glc-gallery-thumb-btn"
                aria-label="<?php echo esc_attr( $photo['alt'] ); ?>"
                data-global-idx="<?php echo $global_idx; ?>">
                <img
                    src="<?php echo esc_url( $photo['thumb'] ); ?>"
                    alt="<?php echo esc_attr( $photo['alt'] ); ?>"
                    loading="lazy">
                <span class="glc-thumb-caption"><?php echo esc_html( $photo['label'] ); ?></span>
            </button>
            <?php endforeach; ?>
        </div>
        <?php endforeach; ?>

        <!-- Lightbox -->
        <div class="glc-lightbox" id="<?php echo esc_attr( $gallery_id ); ?>-lb"
             role="dialog" aria-modal="true" aria-label="Photo viewer" hidden>
            <button class="glc-lb-close" aria-label="Close photo viewer">&#x2715;</button>
            <button class="glc-lb-prev" aria-label="Previous photo">&#x2039;</button>
            <button class="glc-lb-next" aria-label="Next photo">&#x203a;</button>
            <div class="glc-lb-inner">
                <img class="glc-lb-img" src="" alt="">
                <div class="glc-lb-meta">
                    <span class="glc-lb-label"></span>
                    <a class="glc-lb-link" href="" target="_blank" rel="noopener">View outing →</a>
                </div>
            </div>
        </div>
    </div>

    <script>
    (function() {
        var wrap   = document.getElementById(<?php echo wp_json_encode( $gallery_id ); ?>);
        var lb     = document.getElementById(<?php echo wp_json_encode( $gallery_id . '-lb' ); ?>);
        var photos = <?php echo wp_json_encode( array_values( $all_photos ) ); ?>;
        var currentIdx = 0;

        // ── Tab switching ──────────────────────────────────────────────────
        var tabs  = wrap.querySelectorAll('.glc-gallery-tab');
        var grids = wrap.querySelectorAll('.glc-gallery-grid');

        tabs.forEach(function(tab) {
            tab.addEventListener('click', function() {
                var yr = tab.dataset.year;
                tabs.forEach(function(t) {
                    t.classList.remove('glc-tab-active');
                    t.setAttribute('aria-selected', 'false');
                });
                grids.forEach(function(g) { g.classList.remove('glc-grid-active'); });
                tab.classList.add('glc-tab-active');
                tab.setAttribute('aria-selected', 'true');
                wrap.querySelector('.glc-gallery-grid[data-year="' + yr + '"]')
                    .classList.add('glc-grid-active');
            });
        });

        // ── Lightbox ───────────────────────────────────────────────────────
        var lbImg   = lb.querySelector('.glc-lb-img');
        var lbLabel = lb.querySelector('.glc-lb-label');
        var lbLink  = lb.querySelector('.glc-lb-link');

        function showPhoto(idx) {
            if ( idx < 0 ) idx = photos.length - 1;
            if ( idx >= photos.length ) idx = 0;
            currentIdx = idx;
            var p = photos[idx];
            lbImg.src       = p.src;
            lbImg.alt       = p.alt;
            lbLabel.textContent = p.label + (p.date ? '  ·  ' + p.date : '');
            lbLink.href     = p.url;
            lb.hidden = false;
            document.body.style.overflow = 'hidden';
            lb.querySelector('.glc-lb-close').focus();
        }

        function closeLightbox() {
            lb.hidden = true;
            document.body.style.overflow = '';
        }

        wrap.querySelectorAll('.glc-gallery-thumb-btn').forEach(function(btn) {
            btn.addEventListener('click', function() {
                showPhoto( parseInt(btn.dataset.globalIdx, 10) );
            });
        });

        lb.querySelector('.glc-lb-close').addEventListener('click', closeLightbox);
        lb.querySelector('.glc-lb-prev').addEventListener('click', function() { showPhoto(currentIdx - 1); });
        lb.querySelector('.glc-lb-next').addEventListener('click', function() { showPhoto(currentIdx + 1); });

        lb.addEventListener('click', function(e) {
            if ( e.target === lb ) closeLightbox();
        });

        document.addEventListener('keydown', function(e) {
            if ( lb.hidden ) return;
            if ( e.key === 'Escape' )     closeLightbox();
            if ( e.key === 'ArrowLeft' )  showPhoto(currentIdx - 1);
            if ( e.key === 'ArrowRight' ) showPhoto(currentIdx + 1);
        });
    })();
    </script>
    <?php
    return ob_get_clean();
}
