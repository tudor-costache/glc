<?php
/**
 * ACF field group for cleanup_event posts.
 * Registers programmatically so fields are version-controlled
 * alongside the plugin rather than stored only in the DB.
 */
defined( 'ABSPATH' ) || exit;

add_action( 'acf/init', 'glc_register_acf_fields' );
function glc_register_acf_fields() {
    if ( ! function_exists( 'acf_add_local_field_group' ) ) {
        return; // ACF not active
    }

    acf_add_local_field_group( [
        'key'      => 'group_glc_cleanup',
        'title'    => 'Cleanup Details',
        'location' => [ [ [
            'param'    => 'post_type',
            'operator' => '==',
            'value'    => 'cleanup_event',
        ] ] ],
        'menu_order'            => 0,
        'position'              => 'normal',
        'style'                 => 'default',
        'label_placement'       => 'top',
        'instruction_placement' => 'label',
        'fields' => [

            // ── Site ─────────────────────────────────────────────────────
            [
                'key'           => 'field_glc_date',
                'label'         => 'Cleanup Date',
                'name'          => 'cleanup_date',
                'type'          => 'date_picker',
                'display_format'=> 'F j, Y',
                'return_format' => 'Y-m-d',
                'first_day'     => 0,
                'required'      => 1,
                'wrapper'       => [ 'width' => '33' ],
            ],
            [
                'key'           => 'field_glc_site',
                'label'         => 'Site Name',
                'name'          => 'site_name',
                'type'          => 'text',
                'required'      => 1,
                'placeholder'   => 'e.g. Royal City Park – Speed River',
                'wrapper'       => [ 'width' => '67' ],
            ],
            [
                'key'         => 'field_glc_lat',
                'label'       => 'GPS Latitude',
                'name'        => 'gps_lat',
                'type'        => 'number',
                'placeholder' => '43.5448',
                'step'        => 'any',
                'wrapper'     => [ 'width' => '50' ],
            ],
            [
                'key'         => 'field_glc_lon',
                'label'       => 'GPS Longitude',
                'name'        => 'gps_lon',
                'type'        => 'number',
                'placeholder' => '-80.2482',
                'step'        => 'any',
                'wrapper'     => [ 'width' => '50' ],
            ],

            // ── People ───────────────────────────────────────────────────
            [
                'key'         => 'field_glc_volunteers',
                'label'       => 'Volunteers',
                'name'        => 'volunteers',
                'type'        => 'number',
                'min'         => 1,
                'required'    => 1,
                'wrapper'     => [ 'width' => '50' ],
            ],
            [
                'key'         => 'field_glc_hours',
                'label'       => 'Total Volunteer Hours',
                'name'        => 'hours',
                'type'        => 'number',
                'min'         => 0,
                'step'        => '0.5',
                'required'    => 1,
                'wrapper'     => [ 'width' => '50' ],
            ],

            // ── Debris ───────────────────────────────────────────────────
            [
                'key'         => 'field_glc_bags',
                'label'       => 'Bags Collected',
                'name'        => 'bags',
                'type'        => 'number',
                'min'         => 0,
                'wrapper'     => [ 'width' => '50' ],
            ],
            [
                'key'          => 'field_glc_weight',
                'label'        => 'Estimated Weight (kg)',
                'name'         => 'weight_kg',
                'type'         => 'number',
                'min'          => 0,
                'step'         => '0.5',
                'wrapper'      => [ 'width' => '50' ],
            ],
            [
                'key'         => 'field_glc_notable',
                'label'       => 'Notable Finds',
                'name'        => 'notable_finds',
                'type'        => 'text',
                'placeholder' => 'e.g. Shopping cart, tire, propane tank',
                'wrapper'     => [ 'width' => '100' ],
            ],

            // ── Restoration ──────────────────────────────────────────────
            [
                'key'         => 'field_glc_planted',
                'label'       => 'Native Species Planted',
                'name'        => 'species_planted',
                'type'        => 'number',
                'min'         => 0,
                'wrapper'     => [ 'width' => '50' ],
            ],
            [
                'key'         => 'field_glc_bank',
                'label'       => 'Metres of Bank Cleared',
                'name'        => 'meters_bank_cleared',
                'type'        => 'number',
                'min'         => 0,
                'step'        => '0.5',
                'wrapper'     => [ 'width' => '50' ],
            ],

            // ── Nature ───────────────────────────────────────────────────
            [
                'key'         => 'field_glc_wildlife',
                'label'       => 'Wildlife Observed',
                'name'        => 'wildlife_obs',
                'type'        => 'text',
                'placeholder' => 'e.g. Great blue heron, 2 wood ducks',
                'wrapper'     => [ 'width' => '100' ],
            ],

        ], // end fields
    ] );
}
