<?php
/**
 * Great Lake Cleaners — Community Submission System
 *
 * Registers the `glc_submission` post type and provides the
 * [glc_submit_form] shortcode for public cleanup submissions.
 *
 * Flow:
 *   1. Visitor fills out [glc_submit_form] on the "Submit a Cleanup" page
 *   2. Submission saved as post_status = 'pending' (hidden from public)
 *   3. Admin sees it in Submissions menu, reviews, publishes or deletes
 *   4. Published submissions are counted in the stats strip
 *   5. Email notification sent to admin on each new submission
 */

defined( 'ABSPATH' ) || exit;


// ── 1. Register post type ─────────────────────────────────────────────────────

add_action( 'init', 'glc_register_submission_post_type' );
function glc_register_submission_post_type() {
    register_post_type( 'glc_submission', [
        'labels' => [
            'name'               => 'Community Submissions',
            'singular_name'      => 'Submission',
            'add_new'            => 'Add Submission',
            'add_new_item'       => 'Add New Submission',
            'edit_item'          => 'Review Submission',
            'view_item'          => 'View Submission',
            'all_items'          => 'All Submissions',
            'search_items'       => 'Search Submissions',
            'not_found'          => 'No submissions yet.',
            'not_found_in_trash' => 'No submissions in trash.',
        ],
        'public'              => false,   // not publicly queryable on its own
        'show_ui'             => true,    // visible in WP Admin
        'show_in_menu'        => true,
        'menu_position'       => 6,
        'menu_icon'           => 'dashicons-upload',
        'supports'            => [ 'title', 'editor', 'thumbnail' ],
        'capability_type'     => 'post',
        'show_in_rest'        => false,
    ] );
}

// Flush rewrite rules on activation (called from main plugin file)
add_action( 'glc_activate', 'glc_register_submission_post_type' );


// ── 2. Admin columns for Submissions list ─────────────────────────────────────

add_filter( 'manage_glc_submission_posts_columns', function( $cols ) {
    return [
        'cb'           => $cols['cb'],
        'title'        => 'Submitter / Location',
        'glc_site'     => 'Site',
        'glc_date'     => 'Cleanup Date',
        'glc_email'    => 'Email',
        'glc_bags'     => 'Bags',
        'glc_photos'   => 'Photos',
        'date'         => 'Submitted',
    ];
} );

add_action( 'manage_glc_submission_posts_custom_column', function( $col, $post_id ) {
    switch ( $col ) {
        case 'glc_site':
            echo esc_html( get_post_meta( $post_id, 'glc_site_name', true ) ?: '—' );
            break;
        case 'glc_date':
            echo esc_html( get_post_meta( $post_id, 'glc_cleanup_date', true ) ?: '—' );
            break;
        case 'glc_email':
            $email = get_post_meta( $post_id, 'glc_email', true );
            if ( $email ) {
                echo '<a href="mailto:' . esc_attr( $email ) . '">' . esc_html( $email ) . '</a>';
            } else {
                echo '—';
            }
            break;
        case 'glc_bags':
            echo esc_html( get_post_meta( $post_id, 'glc_bags', true ) ?: '—' );
            break;
        case 'glc_photos':
            $ids = get_post_meta( $post_id, 'glc_photo_ids', true );
            echo $ids ? count( (array) $ids ) . ' photo(s)' : '—';
            break;
    }
}, 10, 2 );


// ── 3. Admin meta box — submission details ────────────────────────────────────

add_action( 'add_meta_boxes', function() {
    add_meta_box(
        'glc_submission_details',
        'Submission Details',
        'glc_submission_meta_box_cb',
        'glc_submission',
        'normal',
        'high'
    );
} );

function glc_submission_meta_box_cb( $post ) {
    $fields = [
        'glc_submitter_name' => 'Name',
        'glc_email'          => 'Email',
        'glc_cleanup_date'   => 'Cleanup Date',
        'glc_site_name'      => 'Site / Location',
        'glc_waterway'       => 'Waterway',
        'glc_bags'           => 'Bags Collected',
        'glc_weight_kg'      => 'Approx. Weight (kg)',
        'glc_volunteers'     => 'Volunteers',
        'glc_hours'          => 'Hours',
        'glc_notable_finds'  => 'Notable Finds',
    ];
    echo '<table class="form-table"><tbody>';
    foreach ( $fields as $key => $label ) {
        $val = get_post_meta( $post->ID, $key, true );
        echo '<tr><th>' . esc_html( $label ) . '</th><td>' . esc_html( $val ?: '—' ) . '</td></tr>';
    }
    echo '</tbody></table>';

    // Show submitted photos
    $photo_ids = get_post_meta( $post->ID, 'glc_photo_ids', true );
    if ( ! empty( $photo_ids ) ) {
        echo '<h4 style="margin-top:1em;">Submitted Photos</h4>';
        echo '<div style="display:flex;flex-wrap:wrap;gap:8px;">';
        foreach ( (array) $photo_ids as $att_id ) {
            $thumb = wp_get_attachment_image( $att_id, [ 120, 120 ], false, [ 'style' => 'border-radius:4px;' ] );
            $full  = wp_get_attachment_url( $att_id );
            if ( $thumb && $full ) {
                echo '<a href="' . esc_url( $full ) . '" target="_blank">' . $thumb . '</a>';
            }
        }
        echo '</div>';
    }
}


// ── 4. Admin notice on Submissions list ──────────────────────────────────────

add_action( 'admin_notices', function() {
    $screen = get_current_screen();
    if ( ! $screen || $screen->post_type !== 'glc_submission' ) return;

    $pending = wp_count_posts( 'glc_submission' )->pending ?? 0;
    if ( $pending > 0 ) {
        printf(
            '<div class="notice notice-info"><p><strong>%d pending submission%s</strong> awaiting review. '
            . 'Publish to count it in site stats, or move to trash to remove it.</p></div>',
            (int) $pending,
            $pending === 1 ? '' : 's'
        );
    }
} );


// ── 5. [glc_submit_form] shortcode ───────────────────────────────────────────

add_shortcode( 'glc_submit_form', 'glc_render_submit_form' );

function glc_render_submit_form( $atts ) {
    // Handle POST before any output
    $result = glc_maybe_handle_submission();

    ob_start();

    if ( $result === 'success' ) {
        ?>
        <div class="glc-submit-success">
            <div class="glc-submit-success-icon">🛶</div>
            <h2><?php esc_html_e( 'Cleanup submitted — thank you!', 'great-lake-cleaners' ); ?></h2>
            <p><?php esc_html_e(
                "We'll review it shortly and add it to the map. Every cleanup counts toward protecting the watershed.",
                'great-lake-cleaners'
            ); ?></p>
        </div>
        <?php
        return ob_get_clean();
    }

    $error = is_string( $result ) && $result !== 'success' ? $result : '';

    ?>
    <div class="glc-submit-wrap">

        <div class="glc-submit-intro">
            <p><?php esc_html_e(
                'Did a cleanup on a local waterway? We\'d love to count it. Share what you picked up and we\'ll add it to the community total.',
                'great-lake-cleaners'
            ); ?></p>
        </div>

        <?php if ( $error ) : ?>
            <div class="glc-submit-error">
                <?php echo esc_html( $error ); ?>
            </div>
        <?php endif; ?>

        <form class="glc-submit-form" method="post" enctype="multipart/form-data" novalidate>
            <?php wp_nonce_field( 'glc_submit_cleanup', 'glc_submit_nonce' ); ?>

            <div class="glc-form-section">
                <h3><?php esc_html_e( 'About You', 'great-lake-cleaners' ); ?></h3>

                <div class="glc-field glc-field--half">
                    <label for="glc_submitter_name">
                        <?php esc_html_e( 'Your Name', 'great-lake-cleaners' ); ?>
                        <span class="glc-required" aria-hidden="true">*</span>
                    </label>
                    <input type="text" id="glc_submitter_name" name="glc_submitter_name"
                           required maxlength="100"
                           value="<?php echo esc_attr( $_POST['glc_submitter_name'] ?? '' ); ?>">
                </div>

                <div class="glc-field glc-field--half">
                    <label for="glc_email">
                        <?php esc_html_e( 'Email', 'great-lake-cleaners' ); ?>
                        <span class="glc-field-note"><?php esc_html_e( '(optional — so we can say thanks)', 'great-lake-cleaners' ); ?></span>
                    </label>
                    <input type="email" id="glc_email" name="glc_email"
                           maxlength="200"
                           value="<?php echo esc_attr( $_POST['glc_email'] ?? '' ); ?>">
                </div>
            </div>

            <div class="glc-form-section">
                <h3><?php esc_html_e( 'The Cleanup', 'great-lake-cleaners' ); ?></h3>

                <div class="glc-field glc-field--half">
                    <label for="glc_cleanup_date">
                        <?php esc_html_e( 'Date', 'great-lake-cleaners' ); ?>
                        <span class="glc-required" aria-hidden="true">*</span>
                    </label>
                    <input type="date" id="glc_cleanup_date" name="glc_cleanup_date"
                           required
                           max="<?php echo esc_attr( date( 'Y-m-d' ) ); ?>"
                           value="<?php echo esc_attr( $_POST['glc_cleanup_date'] ?? '' ); ?>">
                </div>

                <div class="glc-field glc-field--half">
                    <label for="glc_waterway">
                        <?php esc_html_e( 'Waterway', 'great-lake-cleaners' ); ?>
                        <span class="glc-required" aria-hidden="true">*</span>
                    </label>
                    <select id="glc_waterway" name="glc_waterway" required>
                        <option value=""><?php esc_html_e( '— Select —', 'great-lake-cleaners' ); ?></option>
                        <?php
                        $waterways = [
                            'Speed River',
                            'Eramosa River',
                            'Hanlon Creek',
                            'Guelph Lake / Reservoir',
                            'Grand River',
                            'Other Waterway',
                        ];
                        $selected = $_POST['glc_waterway'] ?? '';
                        foreach ( $waterways as $w ) {
                            printf(
                                '<option value="%s"%s>%s</option>',
                                esc_attr( $w ),
                                selected( $selected, $w, false ),
                                esc_html( $w )
                            );
                        }
                        ?>
                    </select>
                </div>

                <div class="glc-field">
                    <label for="glc_site_name">
                        <?php esc_html_e( 'Specific Location / Access Point', 'great-lake-cleaners' ); ?>
                        <span class="glc-field-note"><?php esc_html_e( '(e.g. Riverside Park, Starwood Dr. trailhead)', 'great-lake-cleaners' ); ?></span>
                    </label>
                    <input type="text" id="glc_site_name" name="glc_site_name"
                           maxlength="200"
                           value="<?php echo esc_attr( $_POST['glc_site_name'] ?? '' ); ?>">
                </div>
            </div>

            <div class="glc-form-section">
                <h3><?php esc_html_e( 'What You Collected', 'great-lake-cleaners' ); ?></h3>

                <div class="glc-field glc-field--quarter">
                    <label for="glc_bags"><?php esc_html_e( 'Bags', 'great-lake-cleaners' ); ?></label>
                    <input type="number" id="glc_bags" name="glc_bags"
                           min="0" max="999" step="1"
                           value="<?php echo esc_attr( $_POST['glc_bags'] ?? '' ); ?>">
                </div>

                <div class="glc-field glc-field--quarter">
                    <label for="glc_weight_kg"><?php esc_html_e( 'Weight (kg)', 'great-lake-cleaners' ); ?></label>
                    <input type="number" id="glc_weight_kg" name="glc_weight_kg"
                           min="0" max="9999" step="0.1"
                           value="<?php echo esc_attr( $_POST['glc_weight_kg'] ?? '' ); ?>">
                </div>

                <div class="glc-field glc-field--quarter">
                    <label for="glc_volunteers"><?php esc_html_e( 'Volunteers', 'great-lake-cleaners' ); ?></label>
                    <input type="number" id="glc_volunteers" name="glc_volunteers"
                           min="1" max="999" step="1"
                           value="<?php echo esc_attr( $_POST['glc_volunteers'] ?? 1 ); ?>">
                </div>

                <div class="glc-field glc-field--quarter">
                    <label for="glc_hours"><?php esc_html_e( 'Hours', 'great-lake-cleaners' ); ?></label>
                    <input type="number" id="glc_hours" name="glc_hours"
                           min="0" max="99" step="0.5"
                           value="<?php echo esc_attr( $_POST['glc_hours'] ?? '' ); ?>">
                </div>

                <div class="glc-field">
                    <label for="glc_notable_finds">
                        <?php esc_html_e( 'Notable Finds', 'great-lake-cleaners' ); ?>
                        <span class="glc-field-note"><?php esc_html_e( '(anything unusual, large items, or worth sharing)', 'great-lake-cleaners' ); ?></span>
                    </label>
                    <textarea id="glc_notable_finds" name="glc_notable_finds"
                              rows="3" maxlength="1000"><?php echo esc_textarea( $_POST['glc_notable_finds'] ?? '' ); ?></textarea>
                </div>
            </div>

            <div class="glc-form-section">
                <h3><?php esc_html_e( 'Photos', 'great-lake-cleaners' ); ?></h3>
                <div class="glc-field">
                    <label for="glc_photos">
                        <?php esc_html_e( 'Upload Photos', 'great-lake-cleaners' ); ?>
                        <span class="glc-field-note"><?php esc_html_e( '(optional — up to 5 images, JPG/PNG, max 8 MB each)', 'great-lake-cleaners' ); ?></span>
                    </label>
                    <input type="file" id="glc_photos" name="glc_photos[]"
                           accept="image/jpeg,image/png,image/webp"
                           multiple>
                </div>
            </div>

            <div class="glc-form-footer">
                <button type="submit" name="glc_submit_cleanup" class="glc-btn-primary">
                    <?php esc_html_e( 'Submit Cleanup', 'great-lake-cleaners' ); ?>
                </button>
                <p class="glc-form-note">
                    <?php esc_html_e(
                        'Submissions are reviewed before appearing publicly. Your email (if provided) is only used to follow up — never shared.',
                        'great-lake-cleaners'
                    ); ?>
                </p>
            </div>

        </form>
    </div>
    <?php

    return ob_get_clean();
}


// ── 6. Handle form POST ───────────────────────────────────────────────────────

function glc_maybe_handle_submission() {
    if ( ! isset( $_POST['glc_submit_cleanup'] ) ) {
        return null;
    }

    // Nonce check
    if ( ! isset( $_POST['glc_submit_nonce'] )
        || ! wp_verify_nonce( $_POST['glc_submit_nonce'], 'glc_submit_cleanup' ) ) {
        return 'Security check failed. Please refresh the page and try again.';
    }

    // Required fields
    $name = sanitize_text_field( $_POST['glc_submitter_name'] ?? '' );
    $date = sanitize_text_field( $_POST['glc_cleanup_date'] ?? '' );
    $waterway = sanitize_text_field( $_POST['glc_waterway'] ?? '' );

    if ( ! $name ) {
        return 'Please enter your name.';
    }
    if ( ! $date || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
        return 'Please enter a valid cleanup date.';
    }
    if ( strtotime( $date ) > time() ) {
        return 'Cleanup date cannot be in the future.';
    }
    if ( ! $waterway ) {
        return 'Please select a waterway.';
    }

    // Sanitize optional fields
    $email       = sanitize_email( $_POST['glc_email']        ?? '' );
    $site_name   = sanitize_text_field( $_POST['glc_site_name']    ?? '' );
    $bags        = absint( $_POST['glc_bags']        ?? 0 );
    $weight_kg   = (float) ( $_POST['glc_weight_kg']  ?? 0 );
    $volunteers  = max( 1, absint( $_POST['glc_volunteers'] ?? 1 ) );
    $hours       = (float) ( $_POST['glc_hours']      ?? 0 );
    $notable     = sanitize_textarea_field( $_POST['glc_notable_finds'] ?? '' );

    // Create the post (pending = held for moderation)
    $post_id = wp_insert_post( [
        'post_type'   => 'glc_submission',
        'post_status' => 'pending',
        'post_title'  => sprintf( '%s — %s (%s)', $waterway, $site_name ?: 'Waterway cleanup', $date ),
        'post_content'=> $notable,
    ] );

    if ( is_wp_error( $post_id ) ) {
        return 'Could not save your submission. Please try again.';
    }

    // Save meta
    $meta = [
        'glc_submitter_name' => $name,
        'glc_email'          => $email,
        'glc_cleanup_date'   => $date,
        'glc_waterway'       => $waterway,
        'glc_site_name'      => $site_name,
        'glc_bags'           => $bags,
        'glc_weight_kg'      => $weight_kg,
        'glc_volunteers'     => $volunteers,
        'glc_hours'          => $hours,
        'glc_notable_finds'  => $notable,
    ];
    foreach ( $meta as $key => $val ) {
        update_post_meta( $post_id, $key, $val );
    }

    // Handle photo uploads (up to 5)
    $photo_ids = [];
    if ( ! empty( $_FILES['glc_photos']['name'][0] ) ) {
        require_once ABSPATH . 'wp-admin/includes/image.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';

        $allowed_types = [ 'image/jpeg', 'image/png', 'image/webp' ];
        $max_size      = 8 * 1024 * 1024; // 8 MB
        $file_count    = min( 5, count( $_FILES['glc_photos']['name'] ) );

        for ( $i = 0; $i < $file_count; $i++ ) {
            if ( $_FILES['glc_photos']['error'][ $i ] !== UPLOAD_ERR_OK ) continue;
            if ( $_FILES['glc_photos']['size'][ $i ] > $max_size ) continue;
            if ( ! in_array( $_FILES['glc_photos']['type'][ $i ], $allowed_types, true ) ) continue;

            // Reconstruct a single-file $_FILES array for wp_handle_upload
            $_FILES['glc_photo_single'] = [
                'name'     => $_FILES['glc_photos']['name'][ $i ],
                'type'     => $_FILES['glc_photos']['type'][ $i ],
                'tmp_name' => $_FILES['glc_photos']['tmp_name'][ $i ],
                'error'    => $_FILES['glc_photos']['error'][ $i ],
                'size'     => $_FILES['glc_photos']['size'][ $i ],
            ];

            $uploaded = wp_handle_upload( $_FILES['glc_photo_single'], [ 'test_form' => false ] );
            if ( isset( $uploaded['file'] ) ) {
                $att_id = wp_insert_attachment(
                    [
                        'post_mime_type' => $uploaded['type'],
                        'post_title'     => sanitize_file_name( $_FILES['glc_photos']['name'][ $i ] ),
                        'post_status'    => 'inherit',
                        'post_parent'    => $post_id,
                    ],
                    $uploaded['file'],
                    $post_id
                );
                if ( ! is_wp_error( $att_id ) ) {
                    wp_update_attachment_metadata( $att_id, wp_generate_attachment_metadata( $att_id, $uploaded['file'] ) );
                    $photo_ids[] = $att_id;
                    if ( empty( get_post_thumbnail_id( $post_id ) ) ) {
                        set_post_thumbnail( $post_id, $att_id );
                    }
                }
            }
        }

        if ( ! empty( $photo_ids ) ) {
            update_post_meta( $post_id, 'glc_photo_ids', $photo_ids );
        }
    }

    // Email admin
    $admin_email = get_option( 'admin_email' );
    $edit_url    = admin_url( 'post.php?post=' . $post_id . '&action=edit' );
    wp_mail(
        $admin_email,
        sprintf( '[Great Lake Cleaners] New cleanup submission: %s', $waterway ),
        sprintf(
            "A new community cleanup has been submitted.\n\nSubmitter: %s\nWaterway: %s\nDate: %s\nLocation: %s\nBags: %d\nWeight: %.1f kg\n\nReview it here:\n%s",
            $name, $waterway, $date, $site_name ?: '(not specified)',
            $bags, $weight_kg, $edit_url
        )
    );

    return 'success';
}


// ── 7. Frontend styles for the form ──────────────────────────────────────────

add_action( 'wp_head', function() {
    if ( ! is_page() ) return;
    global $post;
    if ( ! $post || ! has_shortcode( $post->post_content, 'glc_submit_form' ) ) return;
    ?>
    <style>
    .glc-submit-wrap { max-width: 720px; margin: 2rem auto; }
    .glc-submit-intro { margin-bottom: 1.5rem; font-size: 1.05rem; color: var(--glc-muted, #666); }
    .glc-submit-error { background: #fef2f2; border-left: 4px solid var(--glc-red, #c03020); padding: .75rem 1rem; margin-bottom: 1.5rem; border-radius: 4px; }
    .glc-submit-success { text-align: center; padding: 3rem 2rem; }
    .glc-submit-success-icon { font-size: 3rem; margin-bottom: 1rem; }
    .glc-submit-success h2 { color: var(--glc-green, #2e8b57); }
    .glc-form-section { margin-bottom: 2rem; padding-bottom: 1.5rem; border-bottom: 1px solid var(--glc-border, #e0e0da); }
    .glc-form-section h3 { font-size: 1rem; text-transform: uppercase; letter-spacing: .05em; color: var(--glc-navy, #1a4a6b); margin-bottom: 1rem; }
    .glc-form-section:last-of-type { border-bottom: none; }
    .glc-submit-form { display: flex; flex-wrap: wrap; gap: 1rem; }
    .glc-form-section { width: 100%; display: flex; flex-wrap: wrap; gap: 1rem; }
    .glc-field { display: flex; flex-direction: column; gap: .35rem; width: 100%; }
    .glc-field--half { flex: 1 1 calc(50% - .5rem); min-width: 200px; }
    .glc-field--quarter { flex: 1 1 calc(25% - .75rem); min-width: 120px; }
    .glc-field label { font-weight: 700; font-size: .9rem; color: var(--glc-text, #222); }
    .glc-field-note { font-weight: 400; color: var(--glc-muted, #666); font-size: .8rem; display: block; }
    .glc-required { color: var(--glc-red, #c03020); margin-left: 2px; }
    .glc-field input,
    .glc-field select,
    .glc-field textarea { padding: .5rem .75rem; border: 1px solid var(--glc-border, #ccc); border-radius: 4px; font-size: 1rem; font-family: inherit; background: #fff; color: var(--glc-text, #222); width: 100%; box-sizing: border-box; }
    .glc-field input:focus,
    .glc-field select:focus,
    .glc-field textarea:focus { outline: 2px solid var(--glc-navy, #1a4a6b); outline-offset: 1px; border-color: var(--glc-navy, #1a4a6b); }
    .glc-field input[type="file"] { padding: .4rem; background: var(--glc-off-white, #fafaf8); }
    .glc-form-footer { width: 100%; display: flex; flex-direction: column; align-items: flex-start; gap: .75rem; }
    .glc-form-note { font-size: .8rem; color: var(--glc-muted, #666); margin: 0; }
    </style>
    <?php
} );
