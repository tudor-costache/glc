<?php
/**
 * Shortcodes
 *
 * [glc_stats]   — cumulative totals banner
 * [glc_map]     — Leaflet map of all cleanup sites
 * [glc_archive] — recent cleanups list (fallback if theme doesn't handle CPT archive)
 */
defined( 'ABSPATH' ) || exit;

// ── Helpers ──────────────────────────────────────────────────────────────────

function glc_get_all_events() {
    return get_posts( [
        'post_type'      => 'cleanup_event',
        'post_status'    => 'publish',
        'posts_per_page' => -1,
        'orderby'        => 'meta_value',
        'meta_key'       => 'cleanup_date',
        'order'          => 'DESC',
    ] );
}

function glc_meta( $post_id, $key, $default = 0 ) {
    $val = get_post_meta( $post_id, $key, true );
    return ( $val !== '' && $val !== false ) ? $val : $default;
}

// ── [glc_stats] ──────────────────────────────────────────────────────────────

add_shortcode( 'glc_stats', 'glc_shortcode_stats' );
function glc_shortcode_stats( $atts ) {
    $events = glc_get_all_events();
    if ( empty( $events ) ) return '';

    $totals = [
        'events'     => count( $events ),
        'volunteers' => 0,
        'hours'      => 0.0,
        'bags'       => 0,
        'weight_kg'  => 0.0,
        'planted'    => 0,
    ];

    foreach ( $events as $e ) {
        $id = $e->ID;
        $totals['volunteers'] += (int)   glc_meta( $id, 'volunteers' );
        $totals['hours']      += (float) glc_meta( $id, 'hours' );
        $totals['bags']       += (int)   glc_meta( $id, 'bags' );
        $totals['weight_kg']  += (float) glc_meta( $id, 'weight_kg' );
        $totals['planted']    += (int)   glc_meta( $id, 'species_planted' );
    }

    $stats = [
        [ 'value' => $totals['events'],                   'label' => 'Cleanups' ],
        [ 'value' => $totals['volunteers'],               'label' => 'Volunteers' ],
        [ 'value' => number_format( $totals['hours'], 1 ),'label' => 'Hours' ],
        [ 'value' => $totals['bags'],                     'label' => 'Bags Out' ],
        [ 'value' => number_format( $totals['weight_kg'], 0 ) . ' kg', 'label' => 'Debris Removed' ],
    ];
    if ( $totals['planted'] > 0 ) {
        $stats[] = [ 'value' => $totals['planted'], 'label' => 'Plants In' ];
    }

    ob_start(); ?>
    <div class="glc-stats-banner">
        <?php foreach ( $stats as $s ) : ?>
        <div class="glc-stat">
            <span class="glc-stat-value"><?php echo esc_html( $s['value'] ); ?></span>
            <span class="glc-stat-label"><?php echo esc_html( $s['label'] ); ?></span>
        </div>
        <?php endforeach; ?>
    </div>
    <?php
    return ob_get_clean();
}

// ── [glc_map] ────────────────────────────────────────────────────────────────

add_shortcode( 'glc_map', 'glc_shortcode_map' );
function glc_shortcode_map( $atts ) {
    $atts = shortcode_atts( [
        'height'  => '480px',
        'post_id' => 0,          // if set, render a single-event map
    ], $atts );

    // Single-event mode (used on single-cleanup_event.php and single-glc_submission.php)
    if ( (int) $atts['post_id'] > 0 ) {
        $pid = (int) $atts['post_id'];
        // Try tracker meta keys first, then glc_ prefixed keys (community submissions)
        $lat = (float) glc_meta( $pid, 'gps_lat', 0 );
        $lon = (float) glc_meta( $pid, 'gps_lon', 0 );
        if ( ! $lat || ! $lon ) {
            $lat = (float) glc_meta( $pid, 'glc_gps_lat', 0 );
            $lon = (float) glc_meta( $pid, 'glc_gps_lon', 0 );
        }
        if ( ! $lat || ! $lon ) return ''; // no coords — skip map
        $markers = [ [
            'lat'   => $lat,
            'lon'   => $lon,
            'title' => get_the_title( $pid ),
            'date'  => glc_meta( $pid, 'cleanup_date', '' ),
            'bags'  => (int) glc_meta( $pid, 'bags' ),
            'url'   => get_permalink( $pid ),
        ] ];
    } else {
        // All-events mode — deduplicate by location, keep highest-stats event per pin
        $events = glc_get_all_events();
        $by_location = [];
        foreach ( $events as $e ) {
            $lat = (float) glc_meta( $e->ID, 'gps_lat', 0 );
            $lon = (float) glc_meta( $e->ID, 'gps_lon', 0 );
            if ( ! $lat || ! $lon ) continue;

            // Round to 5 decimal places for key (~1 m precision)
            $key = round( $lat, 5 ) . ',' . round( $lon, 5 );

            $score = (float) glc_meta( $e->ID, 'weight_kg' )
                   + (int)   glc_meta( $e->ID, 'bags' ) * 2; // weight is primary; bags as tiebreak

            if ( ! isset( $by_location[ $key ] ) || $score > $by_location[ $key ]['score'] ) {
                $by_location[ $key ] = [
                    'score' => $score,
                    'lat'   => $lat,
                    'lon'   => $lon,
                    'title' => get_the_title( $e->ID ),
                    'date'  => glc_meta( $e->ID, 'cleanup_date', '' ),
                    'bags'  => (int) glc_meta( $e->ID, 'bags' ),
                    'url'   => get_permalink( $e->ID ),
                ];
            }
        }
        $markers = array_values( $by_location );
    }

    // Enqueue Leaflet
    wp_enqueue_style(
        'leaflet',
        'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css',
        [], '1.9.4'
    );
    wp_enqueue_script(
        'leaflet',
        'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js',
        [], '1.9.4', true
    );

    $map_id = 'glc-map-' . wp_rand( 1000, 9999 );
    ob_start(); ?>
    <div id="<?php echo esc_attr( $map_id ); ?>"
         class="glc-map"
         style="height:<?php echo esc_attr( $atts['height'] ); ?>; width:100%; border-radius:8px;">
    </div>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        var markers = <?php echo wp_json_encode( $markers ); ?>;
        var map = L.map(<?php echo wp_json_encode( $map_id ); ?>, { zoomControl: false }).setView([43.545, -80.248], 12);
        L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
            attribution: '© <a href="https://openstreetmap.org/copyright">OpenStreetMap</a> contributors © <a href="https://carto.com/attributions">CARTO</a>',
            subdomains: 'abcd',
            maxZoom: 19
        }).addTo(map);

        var icon = L.divIcon({
            className: 'glc-marker',
            html: '<svg width="20" height="26" viewBox="0 0 20 26" xmlns="http://www.w3.org/2000/svg"><path d="M10 0C4.48 0 0 4.48 0 10c0 7.5 10 16 10 16s10-8.5 10-16C20 4.48 15.52 0 10 0z" fill="#1a4a6b"/><circle cx="10" cy="10" r="4" fill="#ffffff"/></svg>',
            iconSize: [20, 26],
            iconAnchor: [10, 26],
            popupAnchor: [0, -28],
        });

        markers.forEach(function(m) {
            var popup = '<strong>' + m.title + '</strong><br>'
                      + m.date + '<br>'
                      + m.bags + ' bags collected<br>'
                      + '<a href="' + m.url + '">View details →</a>';
            L.marker([m.lat, m.lon], {icon: icon})
             .addTo(map)
             .bindPopup(popup);
        });

        // Fit bounds or zoom to single pin
        if (markers.length === 1) {
            map.setView([markers[0].lat, markers[0].lon], 15);
        } else if (markers.length > 1) {
            var latlngs = markers.map(function(m){ return [m.lat, m.lon]; });
            map.fitBounds(latlngs, {padding: [40, 40]});
        }
    });
    </script>
    <?php
    return ob_get_clean();
}

// ── [glc_archive] ────────────────────────────────────────────────────────────

add_shortcode( 'glc_archive', 'glc_shortcode_archive' );
function glc_shortcode_archive( $atts ) {
    $atts   = shortcode_atts( [ 'limit' => 20 ], $atts );
    $events = get_posts( [
        'post_type'      => 'cleanup_event',
        'post_status'    => 'publish',
        'posts_per_page' => (int) $atts['limit'],
        'orderby'        => 'meta_value',
        'meta_key'       => 'cleanup_date',
        'order'          => 'DESC',
    ] );

    if ( empty( $events ) ) {
        return '<p>No cleanups logged yet. Check back soon!</p>';
    }

    ob_start(); ?>
    <div class="glc-archive">
        <?php foreach ( $events as $e ) :
            $id       = $e->ID;
            $date     = glc_meta( $id, 'cleanup_date', '' );
            $site     = glc_meta( $id, 'site_name', get_the_title( $id ) );
            $vols     = (int)   glc_meta( $id, 'volunteers' );
            $bags     = (int)   glc_meta( $id, 'bags' );
            $weight   = (float) glc_meta( $id, 'weight_kg' );
            $planted  = (int)   glc_meta( $id, 'species_planted' );
            $wildlife = glc_meta( $id, 'wildlife_obs', '' );
            $date_fmt = $date ? date( 'F j, Y', strtotime( $date ) ) : '';
        ?>
        <article class="glc-event-card">
            <div class="glc-event-meta">
                <time class="glc-event-date"><?php echo esc_html( $date_fmt ); ?></time>
            </div>
            <h3 class="glc-event-title">
                <a href="<?php echo esc_url( get_permalink( $id ) ); ?>">
                    <?php echo esc_html( $site ); ?>
                </a>
            </h3>
            <div class="glc-event-stats">
                <span>👥 <?php echo $vols; ?> volunteers</span>
                <span>🛍 <?php echo $bags; ?> bags</span>
                <span>⚖ <?php echo number_format( $weight, 0 ); ?> kg</span>
                <?php if ( $planted ) : ?>
                <span>🌿 <?php echo $planted; ?> plants</span>
                <?php endif; ?>
            </div>
            <?php if ( $wildlife ) : ?>
            <p class="glc-event-wildlife">👀 <?php echo esc_html( $wildlife ); ?></p>
            <?php endif; ?>
        </article>
        <?php endforeach; ?>
    </div>
    <?php
    return ob_get_clean();
}
